=== THATCamp Furvious ===
Contributors: chnm, amandafrench
Donate link: http://chnm.gmu.edu/
Related website: http://thatcamp.org
Tags: conferences, unconferences, THATCamp, WordPress, themes, child themes
Version: 

== Description ==

== Installation == 

== Documentation ==

== Changelog ==


== Credits ==
Based on the Furvious WordPress theme by Kreative Themes, available at http://www.kreativethemes.com/furvious/

Funding to create these themes was generously provided by the Mellon Foundation (http://mellon.org) as part of the 2010-2012 grant project "Digital Methods Training at Scale: Leveraging THATCamp Through a Regional System."

