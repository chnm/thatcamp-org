=== THATCamp Graphene ===
Contributors: chnm, amandafrench
Website: http://thatcamp.org
Donate link: http://chnm.gmu.edu/
Tags: conferences, unconferences, THATCamp, WordPress, themes, child themes

== Description ==

== Installation == 

== Documentation ==

== Changelog ==


== Credits ==
Based on the Graphene WordPress theme by silverks, available at http://wordpress.org/extend/themes/graphene 

Funding to create these themes was generously provided by the Mellon Foundation (http://mellon.org) as part of the 2010-2012 grant project "Digital Methods Training at Scale: Leveraging THATCamp Through a Regional System."

